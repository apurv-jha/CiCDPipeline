export class CSVRecord {
	public tenant: any;
	public timeOfCompletion: any;

}
